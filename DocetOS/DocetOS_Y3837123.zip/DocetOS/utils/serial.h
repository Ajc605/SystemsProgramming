#ifndef _SERIAL_H_
#define _SERIAL_H_

void serial_init(void);

#endif /*_SERIAL_H_*/
